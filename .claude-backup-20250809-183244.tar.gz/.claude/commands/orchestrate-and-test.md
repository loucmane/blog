**ORCHESTRATE AND TEST - Unified Workflow Command**

Think deeply about this multi-perspective implementation challenge. You are about to guide a sophisticated orchestration process.

**⚠️ CRITICAL DEPLOYMENT RULE**: ALL agents MUST be deployed using the built-in Task function ONLY. Do NOT use MCP tools (zen, claude-code-bridge, taskmaster-ai, etc.) for agent deployment.

**Variables:**

task_id: $ARGUMENTS
spec_file: $ARGUMENTS
specialists: $ARGUMENTS
depth: $ARGUMENTS
auto_start_servers: $ARGUMENTS
reuse_worktrees: $ARGUMENTS

**ARGUMENTS PARSING:**
Parse the following arguments from "$ARGUMENTS":
1. `task_id` - The TaskMaster task ID to implement (REQUIRED)
2. `spec_file` - Path to the orchestration specification file (default: .claude/specs/orchestrate-test-spec.md)
3. `specialists` - Which specialist perspectives to include (default: "all")
4. `depth` - Number of sub-agents per specialist (default: 2)
5. `auto_start_servers` - Whether to start development servers after orchestration (default: true)
6. `reuse_worktrees` - Whether to reuse existing worktrees from previous runs (default: false)

**PHASE 1: SPECIFICATION LOADING**
1. Load the orchestration specification from `spec_file` (or use default if not provided)
2. This specification contains all agent definitions and orchestration patterns
3. Parse and understand the complete orchestration framework

**PHASE 2: TASK ANALYSIS**
Read the task specification file at `.taskmaster/tasks/task_${String(task_id).padStart(3, '0')}.txt` and extract:
- Task ID, title, status, and priority
- Task description and implementation requirements
- Test strategy for validation
- All subtasks with their status
- Store complete specification for all agents

**PHASE 2.5: TODO LIST CREATION**
Create a structured todo list showing all orchestration phases:
- Use TodoWrite tool to create a comprehensive list
- Include all 10 phases as main items
- Add sub-items for agent deployments
- Track progress throughout execution

**PHASE 3: PRE-FLIGHT VALIDATION**
1. **Project Root Capture**: Store PROJECT_ROOT=$(pwd) for absolute path operations
2. **Git Status Check**: Verify clean working state
3. **Task ID Validation**: Ensure valid task_id format
4. **Worktree Management**: Check existing worktrees with prefix `task-{task_id}-orch`
5. **Port Availability**: Verify ports 3001-3006 are available
6. **Output Directory Setup**: Create `docs/ai/for-agentic-loops/orchestration-outputs/task-{task_id}`
7. **Real-time Monitoring**: Initialize orchestration.log with timestamp
8. **State Management**: Check for existing state to enable resumption

**PHASE 4: CONTRACT GENERATION**
Deploy the Pre-Analysis Agent to generate implementation contracts:

```
TASK: Deploy Pre-Analysis Agent using specification from orchestrate-test-spec.md

CRITICAL: Use the built-in Task function to deploy this agent. Do NOT use MCP tools like zen:chat, claude-code-bridge, or taskmaster-ai.

Context:
- Task specification: [From task file]
- Contracts directory: docs/ai/for-agentic-loops/orchestration-outputs/task-{task_id}/contracts/
- Agent definition: Section 1 from orchestrate-test-spec.md

Deploy the Pre-Analysis Agent using Task tool to generate:
- interface-contract.yaml
- behavior-contract.yaml  
- integration-contract.yaml
- constraints-contract.yaml
```

**PHASE 5: MASTER ORCHESTRATOR ROLE**
You will now assume the role of the Master Orchestrator to analyze and plan the specialist deployments:

```
ROLE: Master Orchestrator

As the Master Orchestrator, you will:
1. **Analyze Contracts**: Review all 4 generated contracts thoroughly
2. **Plan Strategy**: Determine optimal deployment order and approach
3. **Document Approach**: Create and log your orchestration strategy
4. **Prepare Contexts**: Set up deployment contexts for each specialist

Specific actions:
- Read and analyze all contracts in contracts/
- Create orchestration-strategy.md documenting your deployment plan
- Log strategy decisions to orchestration.log with timestamps
- Prepare specialist deployment parameters for Phase 6
- Document which specialists will be activated based on ${specialists}
- Plan how to distribute the task across ${depth} sub-agents per specialist

Context available:
- Task specification: [From task file]
- Requested specialists: ${specialists}
- Sub-agent depth: ${depth}
- All 4 contracts from Pre-Analysis phase
```

**PHASE 6: SPECIALIST ORCHESTRATOR ROLES**
You will now sequentially assume each Specialist Orchestrator role and deploy their sub-agents:

SEQUENTIAL ROLE EXECUTION

For each specialist in ${specialists}, you will:
1. Assume the specialist role
2. Create their worktree
3. Deploy ${depth} sub-agents using the built-in Task function
4. Log deployments and transition to next role

CRITICAL: Use the built-in Task function for ALL agent deployments. Do NOT use MCP tools.

Execute these roles in order (only if included in ${specialists}):

## Performance Specialist Role
If "performance" is in ${specialists}:

TASK: Deploy Performance Specialist Orchestrator

You are now the Performance Specialist. Your focus: speed, efficiency, and optimization.

Actions:
1. Review performance-related contracts from contracts/
2. Deploy ${depth} Performance Sub-Agents IN PARALLEL using the built-in Task function
   - CRITICAL: Deploy all sub-agents in a single message with multiple Task invocations for parallel execution
   - Load deployment instructions from spec file Section "Sub-Agent Deployment Instructions" → "3. Performance Sub-Agents"
   - Each sub-agent gets its own isolated worktree
3. Log deployments to orchestration.log
4. Transition to next role

## Architecture Specialist Role
If "architecture" is in ${specialists}:

TASK: Deploy Architecture Specialist Orchestrator

You are now the Architecture Specialist. Your focus: modularity, scalability, and maintainability.

Actions:
1. Review architecture-related contracts from contracts/
2. Deploy ${depth} Architecture Sub-Agents IN PARALLEL using the built-in Task function
   - CRITICAL: Deploy all sub-agents in a single message with multiple Task invocations for parallel execution
   - Load deployment instructions from spec file Section "Sub-Agent Deployment Instructions" → "4. Architecture Sub-Agents"
   - Each sub-agent gets its own isolated worktree
3. Log deployments to orchestration.log
4. Transition to next role

## UX/DX Specialist Role
If "ux" is in ${specialists}:

TASK: Deploy UX/DX Specialist Orchestrator

You are now the UX/DX Specialist. Your focus: developer and user experience.

Actions:
1. Review UX/DX-related contracts from contracts/
2. Deploy ${depth} UX/DX Sub-Agents IN PARALLEL using the built-in Task function
   - CRITICAL: Deploy all sub-agents in a single message with multiple Task invocations for parallel execution
   - Load deployment instructions from spec file Section "Sub-Agent Deployment Instructions" → "5. UX/DX Sub-Agents"
   - Each sub-agent gets its own isolated worktree
3. Log deployments to orchestration.log
4. Transition to next role

## Accessibility Specialist Role
If "accessibility" is in ${specialists}:

TASK: Deploy Accessibility Specialist Orchestrator

You are now the Accessibility Specialist. Your focus: WCAG compliance and inclusive design.

Actions:
1. Review accessibility-related contracts from contracts/
2. Deploy ${depth} Accessibility Sub-Agents IN PARALLEL using the built-in Task function
   - CRITICAL: Deploy all sub-agents in a single message with multiple Task invocations for parallel execution
   - Load deployment instructions from spec file Section "Sub-Agent Deployment Instructions" → "6. Accessibility Sub-Agents"
   - Each sub-agent gets its own isolated worktree
3. Log deployments to orchestration.log
4. Transition to next role

## Innovation Specialist Role
If "innovation" is in ${specialists}:

TASK: Deploy Innovation Specialist Orchestrator

You are now the Innovation Specialist. Your focus: emerging patterns and future-proofing.

Actions:
1. Review innovation opportunities in contracts/
2. Deploy ${depth} Innovation Sub-Agents IN PARALLEL using the built-in Task function
   - CRITICAL: Deploy all sub-agents in a single message with multiple Task invocations for parallel execution
   - Load deployment instructions from spec file Section "Sub-Agent Deployment Instructions" → "7. Innovation Sub-Agents"
   - Each sub-agent gets its own isolated worktree
3. Log deployments to orchestration.log
4. Complete specialist phases

Note: Execute each role completely before moving to the next. This is sequential, not parallel.

**PHASE 7: EVALUATION**
Deploy the Evaluation Orchestrator to analyze all implementations:

```
TASK: Deploy Evaluation Orchestrator using specification from orchestrate-test-spec.md

CRITICAL: Use Task tool ONLY to deploy this agent. Do NOT use MCP tools.

Context:
- All implementation worktrees
- Contracts for compliance checking
- Agent definition: Section 8 from orchestrate-test-spec.md

Deploy using built-in Task function to analyze all implementations and create evaluation matrix.
```

**PHASE 8: SUMMARIZATION**
Deploy all Summarization Agents in parallel:

```
TASK: Deploy 5 Summarization Agents using specifications from orchestrate-test-spec.md

CRITICAL: Use the built-in Task function for ALL agent deployments. Do NOT use MCP tools.

Deploy ALL 5 summarizers IN A SINGLE MESSAGE with multiple Task invocations for true parallel execution:
- Performance Summarizer (Section 9)
- Architecture Summarizer (Section 10)
- UX/DX Summarizer (Section 11)
- Accessibility Summarizer (Section 12)
- Innovation Summarizer (Section 13)

Each creates a structured 500-word summary.
```

**PHASE 9: SYNTHESIS**
Deploy the Synthesis Orchestrator for final implementation:

```
TASK: Deploy Synthesis Orchestrator using specification from orchestrate-test-spec.md

CRITICAL: Use Task tool ONLY to deploy this agent. Do NOT use MCP tools.

Context:
- All summaries (500 words each)
- Evaluation report
- Contracts for compliance
- Agent definition: Section 14 from orchestrate-test-spec.md

Deploy using built-in Task function to create optimal implementation combining best elements.
```

**PHASE 10: SERVER MANAGEMENT**
If auto_start_servers is true:
1. Create server management script
2. Start development servers on ports 3001-3006
3. Create tmux session for monitoring
4. Generate comparison dashboard HTML

**EXECUTION SUMMARY:**
Total agents deployed: 23 (with default depth=2)
- 1 Pre-Analysis Agent
- 1 Master Orchestrator
- 5 Specialist Orchestrators
- 10 Sub-Agents (2 per specialist)
- 1 Evaluation Orchestrator
- 5 Summarization Agents
- 1 Synthesis Orchestrator

Monitor progress: `tail -f docs/ai/for-agentic-loops/orchestration-outputs/task-{task_id}/logs/orchestration.log`

**USAGE:**
- Simplest (positional): `/orchestrate-and-test 7`
- With custom spec (positional): `/orchestrate-and-test 7 .claude/specs/orchestrate-test-spec.md`
- Named arguments: `/orchestrate-and-test task_id=7 spec_file=.claude/specs/orchestrate-test-spec.md`
- Limited specialists: `/orchestrate-and-test 7 default performance,architecture 2`
- All options (named): `/orchestrate-and-test task_id=7 specialists=performance,architecture depth=2 auto_start_servers=false`