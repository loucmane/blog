# Orchestrate-Test Specification

## Core Challenge

Implement a TaskMaster task through multi-perspective exploration, where 5 specialist orchestrators guide sub-agents to create diverse implementations. Each perspective brings unique expertise, resulting in 15+ implementation variations that are synthesized into an optimal solution.

## Orchestration Flow

1. **Pre-Analysis**: Generate shared contracts for coherent implementations
2. **Specialist Orchestration**: 5 perspectives deploy sub-agents in parallel
3. **Evaluation**: Review all implementations for insights
4. **Summarization**: Extract key learnings from each perspective
5. **Synthesis**: Combine best elements into unified solution

## Key Variables

- **task_id**: The TaskMaster task ID to implement
- **specialists**: Which specialist perspectives to include (comma-separated or "all")
- **depth**: Number of sub-agents per specialist (affects total implementations)
- **auto_start_servers**: Whether to start development servers after orchestration
- **reuse_worktrees**: Whether to reuse existing worktrees from previous runs
- **PROJECT_ROOT**: Captured at orchestration start for absolute path operations

## Important Clarification

- **Task function**: The built-in capability to deploy autonomous AI agents
- **MCP tools**: External tools starting with "mcp__" (do NOT use for agent deployment)

## Absolute Path Approach

To ensure proper worktree isolation, all sub-agents receive explicit absolute path instructions:
- PROJECT_ROOT is captured in Phase 3 of orchestration
- All worktree operations use absolute paths: ${PROJECT_ROOT}/.worktrees/...
- Each sub-agent creates its own numbered worktree
- This prevents working directory inheritance issues discovered during testing

## Agent Specifications

### 1. Pre-Analysis Agent

**Purpose**: Generate implementation contracts that will guide all other agents.

**Context Variables**:
- Task specification from `.taskmaster/tasks/task_${String(task_id).padStart(3, '0')}.txt`
- Task ID: ${task_id}
- Task title: ${task_title}
- Task subtasks: ${task_subtasks}
- Output Directory: ${CONTRACTS_DIR}
- Current Branch: ${CURRENT_BRANCH}
- Project Root: ${PROJECT_ROOT} (captured in Phase 3 for absolute paths)

**Requirements**:
1. Analyze the provided task specification thoroughly
2. Study existing codebase patterns and conventions
3. Consider all 5 specialist perspectives (Performance, Architecture, UX/DX, Accessibility, Innovation)
4. Generate 4 critical contract files:

   a) `${CONTRACTS_DIR}/interface-contract.yaml`
      - Component props/API interface specifications
      - Event handlers and callback signatures
      - TypeScript type definitions
      - Return value contracts

   b) `${CONTRACTS_DIR}/behavior-contract.yaml`
      - Core functionality requirements
      - User interaction patterns
      - State management approach
      - Error handling behavior

   c) `${CONTRACTS_DIR}/integration-contract.yaml`
      - File naming conventions
      - Import/export patterns
      - Theme integration approach
      - Testing requirements

   d) `${CONTRACTS_DIR}/constraints-contract.yaml`
      - Performance budgets
      - Browser compatibility requirements
      - Accessibility standards
      - Code style constraints

**Critical Instructions**:
- Read the ENTIRE task specification first before generating contracts
- Make contracts specific to ${task_title}, not generic
- Consider how different specialists will interpret requirements
- Ensure contracts enable diversity while maintaining compatibility
- Include concrete examples in each contract file

**Output Requirements**:
- Generate all 4 YAML contract files
- Each file must be syntactically valid YAML
- Include comments explaining reasoning
- Provide specific values, not just categories
- Save all files to ${CONTRACTS_DIR}/

### 2. Master Orchestrator (Role)

**Purpose**: A role assumed by the main session to analyze contracts and plan specialist deployments.

**Role Definition**: The main session temporarily becomes the Master Orchestrator to coordinate the multi-perspective implementation strategy.

**Context Available**:
- Task specification: [Full content from task file]
- Requested specialists: ${specialists}
- Depth per specialist: ${depth}
- Contracts directory: ${CONTRACTS_DIR}
- Orchestration output: ${ORCHESTRATION_DIR}
- All 4 generated contracts

**Actions in this Role**:
1. Read and thoroughly analyze all implementation contracts
2. Create comprehensive orchestration strategy document
3. Determine specialist execution order based on ${specialists}
4. Document deployment approach in orchestration-strategy.md
5. Log strategic decisions to orchestration.log
6. Prepare deployment contexts for each specialist role
7. Plan distribution of work across ${depth} sub-agents per specialist

**Specialist Execution Order** (if all selected):
1. Performance Specialist Role
2. Architecture Specialist Role  
3. UX/DX Specialist Role
4. Accessibility Specialist Role
5. Innovation Specialist Role

**Note**: This is a ROLE played by the main session, not a separate deployed agent.

### 3. Performance Specialist Orchestrator (Role)

**Purpose**: Create high-performance implementations focusing on speed and efficiency.

**Role Transition**: The main session assumes this specialist role after completing the Master Orchestrator role.

**Absolute Path Approach**: 
The main session deploys sub-agents with explicit absolute path instructions to ensure proper isolation. Each sub-agent creates and navigates to its own worktree using absolute paths.

**Worktree Details**:
- Each sub-agent creates its own worktree: `.worktrees/task-${task_id}-orch-perf-{number}`
- All paths use ${PROJECT_ROOT} for absolute references
- No working directory inheritance issues

**Focus Areas**:
- Load time optimization
- Runtime performance
- Memory efficiency
- Bundle size reduction
- Network optimization

**Sub-Agent Deployment**:
In this role, the main session directly deploys ${depth} Performance Sub-Agents using the built-in Task function, each exploring different optimization strategies:
- Agent 1: Aggressive code splitting and lazy loading
- Agent 2: SSG/ISR optimization with minimal client JS
- Agent 3: Web Worker offloading for heavy computations
- Additional agents explore combinations and advanced techniques

**Implementation Requirements**:
- Each sub-agent works in its own isolated worktree: `.worktrees/task-${task_id}-orch-perf-{number}`
- Follow contracts from ${CONTRACTS_DIR}
- Focus on 98+ Lighthouse scores
- Implement performance monitoring
- Document optimization decisions

### 4. Architecture Specialist Orchestrator (Role)

**Purpose**: Create well-structured, maintainable implementations with excellent patterns.

**Role Transition**: The main session assumes this specialist role after completing the Performance Specialist role.

**Absolute Path Approach**: 
The main session deploys sub-agents with explicit absolute path instructions to ensure proper isolation. Each sub-agent creates and navigates to its own worktree using absolute paths.

**Worktree Details**:
- Each sub-agent creates its own worktree: `.worktrees/task-${task_id}-orch-arch-{number}`
- All paths use ${PROJECT_ROOT} for absolute references
- No working directory inheritance issues

**Focus Areas**:
- Component composition patterns
- State management architecture
- Separation of concerns
- Scalability patterns
- Type safety

**Sub-Agent Deployment**:
In this role, the main session directly deploys ${depth} Architecture Sub-Agents using the built-in Task function exploring different patterns:
- Agent 1: Compound component pattern with maximum flexibility
- Agent 2: Atomic design with strict hierarchy
- Agent 3: Feature-sliced design for modularity
- Additional agents explore hybrid approaches

**Implementation Requirements**:
- Each sub-agent works in its own isolated worktree: `.worktrees/task-${task_id}-orch-arch-{number}`
- Emphasize clean code principles
- Strong TypeScript usage
- Clear module boundaries
- Comprehensive documentation

### 5. UX/DX Specialist Orchestrator (Role)

**Purpose**: Create implementations optimizing both user and developer experience.

**Role Transition**: The main session assumes this specialist role after completing the Architecture Specialist role.

**Absolute Path Approach**: 
The main session deploys sub-agents with explicit absolute path instructions to ensure proper isolation. Each sub-agent creates and navigates to its own worktree using absolute paths.

**Worktree Details**:
- Each sub-agent creates its own worktree: `.worktrees/task-${task_id}-orch-ux-{number}`
- All paths use ${PROJECT_ROOT} for absolute references
- No working directory inheritance issues

**Focus Areas**:
- Intuitive user interactions
- Developer ergonomics
- API design
- Error messaging
- Documentation quality

**Sub-Agent Deployment**:
In this role, the main session directly deploys ${depth} UX/DX Sub-Agents using the built-in Task function focusing on experience:
- Agent 1: Maximum user delight with micro-interactions
- Agent 2: Developer-first with excellent APIs
- Agent 3: Balanced approach with great defaults
- Additional agents explore specific use cases

**Implementation Requirements**:
- Each sub-agent works in its own isolated worktree: `.worktrees/task-${task_id}-orch-ux-{number}`
- Include usage examples
- Storybook stories if applicable
- Clear error messages
- Intuitive prop names

### 6. Accessibility Specialist Orchestrator (Role)

**Purpose**: Create implementations exceeding WCAG standards with inclusive design.

**Role Transition**: The main session assumes this specialist role after completing the UX/DX Specialist role.

**Absolute Path Approach**: 
The main session deploys sub-agents with explicit absolute path instructions to ensure proper isolation. Each sub-agent creates and navigates to its own worktree using absolute paths.

**Worktree Details**:
- Each sub-agent creates its own worktree: `.worktrees/task-${task_id}-orch-a11y-{number}`
- All paths use ${PROJECT_ROOT} for absolute references
- No working directory inheritance issues

**Focus Areas**:
- Screen reader optimization
- Keyboard navigation
- Color contrast
- Focus management
- ARIA implementation

**Sub-Agent Deployment**:
In this role, the main session directly deploys ${depth} Accessibility Sub-Agents using the built-in Task function with different approaches:
- Agent 1: ARIA-first with comprehensive announcements
- Agent 2: Semantic HTML maximalist approach
- Agent 3: Progressive enhancement focus
- Additional agents explore assistive technology optimizations

**Implementation Requirements**:
- Each sub-agent works in its own isolated worktree: `.worktrees/task-${task_id}-orch-a11y-{number}`
- WCAG 2.1 AAA compliance where possible
- Keyboard navigation documentation
- Screen reader testing notes
- Focus flow diagrams

### 7. Innovation Specialist Orchestrator (Role)

**Purpose**: Create boundary-pushing implementations with creative solutions.

**Role Transition**: The main session assumes this specialist role after completing the Accessibility Specialist role.

**Absolute Path Approach**: 
The main session deploys sub-agents with explicit absolute path instructions to ensure proper isolation. Each sub-agent creates and navigates to its own worktree using absolute paths.

**Worktree Details**:
- Each sub-agent creates its own worktree: `.worktrees/task-${task_id}-orch-innov-{number}`
- All paths use ${PROJECT_ROOT} for absolute references
- No working directory inheritance issues

**Focus Areas**:
- Novel interaction patterns
- Creative visual solutions
- Emerging web APIs
- Experimental features
- Future-facing patterns

**Sub-Agent Deployment**:
In this role, the main session directly deploys ${depth} Innovation Sub-Agents using the built-in Task function exploring possibilities:
- Agent 1: Cutting-edge CSS and animations
- Agent 2: AI-enhanced interactions
- Agent 3: Novel state management approaches
- Additional agents combine innovations

**Implementation Requirements**:
- Each sub-agent works in its own isolated worktree: `.worktrees/task-${task_id}-orch-innov-{number}`
- Document browser compatibility
- Provide fallbacks
- Explain innovative aspects
- Include demos

### 8. Evaluation Orchestrator

**Purpose**: Review all implementations and extract insights for synthesis.

**Evaluation Process**:
1. Scan all worktrees for implementations
2. Analyze each implementation against:
   - Contract compliance
   - Unique strengths
   - Potential issues
   - Innovation value
   - Integration complexity
3. Create evaluation matrix
4. Identify best practices from each
5. Note patterns across perspectives
6. Prepare insights for synthesis

**Output Requirements**:
- Evaluation report in ${ORCHESTRATION_DIR}/evaluation/
- Comparison matrix
- Strengths/weaknesses analysis
- Recommendations for synthesis
- Pattern identification

### 9-13. Summarizer Agents (Performance, Architecture, UX/DX, Accessibility, Innovation)

**Purpose**: Extract key learnings from each specialist perspective.

**Summarization Focus**:
- Successful patterns discovered
- Common challenges faced
- Unique insights gained
- Reusable solutions
- Perspective-specific best practices

**Output Requirements**:
- Summary report per perspective
- Code snippets of best solutions
- Decision rationale
- Performance metrics (if applicable)
- Future recommendations

### 14. Synthesis Orchestrator

**Purpose**: Combine the best elements from all implementations into an optimal solution.

**Synthesis Strategy**:
1. Read all evaluation reports and summaries
2. Identify non-conflicting best practices
3. Resolve conflicts through priority ranking
4. Create unified implementation plan
5. Generate final synthesized code
6. Document decision rationale
7. Create integration guide

**Output Requirements**:
- Final implementation in main branch
- Synthesis decision document
- Integration guide
- Performance validation
- Migration notes from any perspective

## Sub-Agent Deployment Instructions

### 3. Performance Sub-Agents

#### 3.1 Performance Sub-Agent 1
You are Performance Sub-Agent 1 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-perf-1 -b task-${task_id}-orch-perf-1
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-perf-1
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-perf-1/...

THEN implement with focus on: render optimization and initial load performance

Context Available:
- Task specification from Pre-Analysis phase
- Performance contracts from ${CONTRACTS_DIR}
- Project root: ${PROJECT_ROOT}

#### 3.2 Performance Sub-Agent 2
You are Performance Sub-Agent 2 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-perf-2 -b task-${task_id}-orch-perf-2
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-perf-2
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-perf-2/...

THEN implement with focus on: bundle efficiency and code splitting strategies

#### 3.3 Performance Sub-Agent 3 (if depth=3)
You are Performance Sub-Agent 3 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-perf-3 -b task-${task_id}-orch-perf-3
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-perf-3
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-perf-3/...

THEN implement with focus on: runtime performance and optimization

### 4. Architecture Sub-Agents

#### 4.1 Architecture Sub-Agent 1
You are Architecture Sub-Agent 1 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-arch-1 -b task-${task_id}-orch-arch-1
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-arch-1
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-arch-1/...

THEN implement with focus on: component modularity and separation of concerns

#### 4.2 Architecture Sub-Agent 2
You are Architecture Sub-Agent 2 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-arch-2 -b task-${task_id}-orch-arch-2
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-arch-2
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-arch-2/...

THEN implement with focus on: system scalability and extensibility patterns

#### 4.3 Architecture Sub-Agent 3 (if depth=3)
You are Architecture Sub-Agent 3 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-arch-3 -b task-${task_id}-orch-arch-3
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-arch-3
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-arch-3/...

THEN implement with focus on: dependency management and architecture patterns

### 5. UX/DX Sub-Agents

#### 5.1 UX/DX Sub-Agent 1
You are UX/DX Sub-Agent 1 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-ux-1 -b task-${task_id}-orch-ux-1
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-ux-1
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-ux-1/...

THEN implement with focus on: developer ergonomics and API design

#### 5.2 UX/DX Sub-Agent 2
You are UX/DX Sub-Agent 2 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-ux-2 -b task-${task_id}-orch-ux-2
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-ux-2
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-ux-2/...

THEN implement with focus on: user interactions and interface patterns

#### 5.3 UX/DX Sub-Agent 3 (if depth=3)
You are UX/DX Sub-Agent 3 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-ux-3 -b task-${task_id}-orch-ux-3
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-ux-3
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-ux-3/...

THEN implement with focus on: documentation and example creation

### 6. Accessibility Sub-Agents

#### 6.1 Accessibility Sub-Agent 1
You are Accessibility Sub-Agent 1 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-a11y-1 -b task-${task_id}-orch-a11y-1
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-a11y-1
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-a11y-1/...

THEN implement with focus on: WCAG 2.1 AA compliance implementation

#### 6.2 Accessibility Sub-Agent 2
You are Accessibility Sub-Agent 2 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-a11y-2 -b task-${task_id}-orch-a11y-2
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-a11y-2
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-a11y-2/...

THEN implement with focus on: assistive technology support

#### 6.3 Accessibility Sub-Agent 3 (if depth=3)
You are Accessibility Sub-Agent 3 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-a11y-3 -b task-${task_id}-orch-a11y-3
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-a11y-3
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-a11y-3/...

THEN implement with focus on: keyboard navigation patterns

### 7. Innovation Sub-Agents

#### 7.1 Innovation Sub-Agent 1
You are Innovation Sub-Agent 1 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-innov-1 -b task-${task_id}-orch-innov-1
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-innov-1
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-innov-1/...

THEN implement with focus on: cutting-edge patterns and techniques

#### 7.2 Innovation Sub-Agent 2
You are Innovation Sub-Agent 2 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-innov-2 -b task-${task_id}-orch-innov-2
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-innov-2
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-innov-2/...

THEN implement with focus on: future adaptability and evolution paths

#### 7.3 Innovation Sub-Agent 3 (if depth=3)
You are Innovation Sub-Agent 3 for Task ${task_id}.

CRITICAL INSTRUCTIONS - USE ABSOLUTE PATHS:
1. Create the .worktrees directory if needed: mkdir -p ${PROJECT_ROOT}/.worktrees
2. Create git worktree at ABSOLUTE path: 
   git worktree add ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-innov-3 -b task-${task_id}-orch-innov-3
3. Navigate using ABSOLUTE path: cd ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-innov-3
4. Verify location: pwd (should show the worktree path)
5. All file operations use ABSOLUTE paths: ${PROJECT_ROOT}/.worktrees/task-${task_id}-orch-innov-3/...

THEN implement with focus on: experimental feature exploration

## Output Structure

```
docs/ai/for-agentic-loops/orchestration-outputs/task-{task_id}/
├── contracts/
│   ├── interface-contract.yaml
│   ├── behavior-contract.yaml
│   ├── integration-contract.yaml
│   └── constraints-contract.yaml
├── analysis/
│   └── pre-analysis-report.md
├── implementations/
│   ├── performance/
│   ├── architecture/
│   ├── ux-dx/
│   ├── accessibility/
│   └── innovation/
├── evaluation/
│   └── evaluation-matrix.md
├── summaries/
│   ├── performance-summary.md
│   ├── architecture-summary.md
│   ├── ux-dx-summary.md
│   ├── accessibility-summary.md
│   └── innovation-summary.md
├── synthesis/
│   ├── synthesis-plan.md
│   └── final-implementation/
├── logs/
│   └── orchestration.log
└── state/
    └── orchestration-state.json
```

## Success Criteria

1. All requested specialists deploy successfully
2. Each specialist creates ${depth} implementations
3. All implementations follow contracts
4. Evaluation identifies clear patterns
5. Synthesis produces optimal solution
6. Task implementation is complete and tested
7. All outputs are properly documented

## Parallel Execution Notes

- Specialists run in parallel after Pre-Analysis
- Each specialist manages its own sub-agents
- Real-time monitoring via orchestration.log
- State management enables resumption
- Resource allocation prevents conflicts